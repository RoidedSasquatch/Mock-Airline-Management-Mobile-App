package com.example.cst2335_group_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
